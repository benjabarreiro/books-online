import React from "react";
import ItemDetailContainer from "../components/ItemDetailContainer/ItemDetailContainer";

export default function Detail() {

  return (
    <div className="App">
      <ItemDetailContainer />
    </div>
  );
}
